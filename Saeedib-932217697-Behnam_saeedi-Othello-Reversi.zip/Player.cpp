#include "Player.h"

Player::Player(char symb) : symbol(symb) {

}

Player::~Player() {

}
