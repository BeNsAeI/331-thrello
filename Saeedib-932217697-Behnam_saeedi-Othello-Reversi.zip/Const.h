#ifndef CONST_H
#define CONST_H
#define DEBUG 0
#define NOAI 0
#define AI 1
#endif